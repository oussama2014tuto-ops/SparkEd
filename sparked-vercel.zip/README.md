# SparkEd — deploy on Vercel

SparkEd is an interactive English-learning platform (LMS): teachers build
multimedia courses, students learn by doing (quizzes, drag & drop, games,
branching scenarios, case studies, peer review) with gamification, discussions,
accessibility settings, and two AI activities (Mind Map, Six Thinking Hats).

This folder is a ready-to-deploy Vercel project.

```
.
├── index.html      ← the whole app (static page)
├── api/
│   └── ai.js       ← serverless function that proxies AI calls to Anthropic
├── package.json
└── README.md
```

## What you need
- A free **Vercel** account → https://vercel.com
- An **Anthropic API key** (only needed for the two AI activities) →
  https://console.anthropic.com  → Settings → API Keys. The key is used by
  your server function only; it is never sent to the browser.

---

## Option A — deploy from the dashboard (no command line)

1. Put these files in a folder and push them to a new **GitHub** repo
   (or drag-and-drop the folder when prompted by Vercel).
2. Go to Vercel → **Add New… → Project** → import the repo.
3. Framework preset: **Other** (leave build settings empty — it's a static
   site with serverless functions; Vercel detects `/api` automatically).
4. Before/after the first deploy, open **Project → Settings → Environment
   Variables** and add:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** your `sk-ant-...` key
   Then **redeploy** (Deployments → ⋯ → Redeploy) so the function picks it up.
5. Open the generated `https://<your-project>.vercel.app` URL. Done.

## Option B — deploy with the Vercel CLI

```bash
npm i -g vercel          # install the CLI once
cd sparked               # this folder
vercel                   # follow the prompts (link/create project)
vercel env add ANTHROPIC_API_KEY     # paste your key when asked
vercel --prod            # deploy to production
```

---

## How it works
- `index.html` is served as a static page.
- Account/progress data is stored in the browser via **localStorage**
  (a small shim near the top of `index.html`). It persists on that
  browser/device.
- The Mind Map and Six Hats activities `POST /api/ai`. The function in
  `api/ai.js` attaches your `ANTHROPIC_API_KEY` and forwards the request to
  Anthropic, so the key never reaches the browser.

To change the AI model, edit the `model` default in `api/ai.js`.

---

## Current limitations (and the path to a "full" production app)
This is a functional prototype. On a real deployment:

1. **Accounts & data are per-browser (localStorage), not shared.** A teacher
   and a student see each other's courses/submissions only within the *same*
   browser. True multi-user, multi-device accounts need a backend database
   (e.g. Postgres or MongoDB) with real authentication.
2. **Multimedia "uploads" are links, not hosted files.** Real file upload/
   hosting needs object storage (e.g. S3-compatible).
3. **Payments (SATIM / Chargily / SlickPay) are simulated.** Clearing real
   DZD payments requires a server integration with each provider and merchant
   credentials.

When you're ready, the natural next step is a small backend (Vercel serverless
functions or a separate Node/Express service) plus a database and object
storage — at which point the same `index.html` front end can talk to real
`/api/...` routes instead of localStorage.
