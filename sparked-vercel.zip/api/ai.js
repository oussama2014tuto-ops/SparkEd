// SparkEd — AI proxy (Vercel Serverless Function, Node.js runtime)
//
// The browser calls POST /api/ai with the same body the Anthropic Messages
// API expects ({ model, max_tokens, system, messages }). This function adds
// the secret API key (kept on the server, never shipped to the browser) and
// forwards the request to Anthropic, then returns the response unchanged.
//
// Required environment variable (set it in the Vercel dashboard):
//   ANTHROPIC_API_KEY = sk-ant-...

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) {
    res.status(500).json({ error: 'Server is missing ANTHROPIC_API_KEY. Add it in your Vercel project settings.' });
    return;
  }

  try {
    let body = req.body;
    if (typeof body === 'string') {
      try { body = JSON.parse(body); } catch (e) { body = {}; }
    }
    body = body || {};

    const payload = {
      model: body.model || 'claude-sonnet-4-20250514',
      max_tokens: body.max_tokens || 900,
      system: body.system,
      messages: Array.isArray(body.messages) ? body.messages : []
    };

    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': key,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify(payload)
    });

    const data = await r.json();
    res.status(r.status).json(data);
  } catch (err) {
    res.status(500).json({ error: String((err && err.message) || err) });
  }
};
